import Column from "./Columns";

function Table() {
	return(
		<table>
			<tbody>
				<tr>
					<Column />
				</tr>
			</tbody>
		</table>
	)
}

export default Table;