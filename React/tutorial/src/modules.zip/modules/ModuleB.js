import React from "react";
import ModuleC from "./ModuleC";

function ModuleB() {
		return(
			<div>
				<ModuleC />
			</div>
		)
}

export default ModuleB