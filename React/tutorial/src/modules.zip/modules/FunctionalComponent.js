import React from 'react';

// named export. when import name should be same.
// export const Greet = () => <h1> hello world!!! </h1>;

//default exports
const greet = () => <h1> hello world!!! </h1>;
export default greet;
