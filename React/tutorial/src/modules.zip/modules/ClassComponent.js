import React from "react";

class Welcome extends React.Component {
	render (){
		return <h1> Hello World!!! </h1>;
	}
}

export default Welcome;