import React from "react";
import ModuleB from "./ModuleB";

function ModuleA() {
		return(
			<div>
				<ModuleB />
			</div>
		)
}

export default ModuleA